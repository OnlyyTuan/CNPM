// backend/src/index.js (Điểm khởi động chính)
require("dotenv").config(); // Load biến môi trường từ .env
const app = require("./app"); // Express App
const db = require("./db"); // Kết nối Database
const config = require("./config/app.config"); // Cấu hình chung

// Hàm chính để khởi động ứng dụng
async function startServer() {
  console.log("--- Đồ án SmartSchoolBus 1.0 Backend ---");
  try {
    // <<< THÊM TRY
    // 1. Kết nối Database
    await db.connectDB(); // Hàm này phải đảm bảo trả về lỗi nếu kết nối thất bại
    // Đánh dấu DB đã kết nối để các phần khác có thể kiểm tra
    app.locals.dbConnected = true;

    const PORT = config.PORT;
    app.listen(PORT, () => {
      console.log(`🚀 Server đang chạy trên cổng: http://localhost:${PORT}`);
    });
  } catch (error) {
    // <<< THÊM CATCH
    // Nếu không kết nối được DB, log lỗi nhưng KHÔNG thoát process.
    // Thay vào đó khởi động server ở chế độ degraded để dễ debug phía client.
    console.error(
      "🚨 Lỗi khi kết nối Database (server sẽ chạy ở chế độ degraded):",
      error.message
    );
    app.locals.dbConnected = false;
    const PORT = config.PORT;
    app.listen(PORT, () => {
      console.log(
        `⚠️ Server khởi động nhưng chưa kết nối DB. Truy cập http://localhost:${PORT}/api/v1/db-status để kiểm tra chi tiết.`
      );
    });
  }
}

// Chạy hàm khởi động
startServer();

// Bắt unhandled promise rejections
process.on("unhandledRejection", (reason, promise) => {
  console.error("🚨 Unhandled Rejection at:", promise, "reason:", reason);
  process.exit(1);
});

// Bắt uncaught exceptions
process.on("uncaughtException", (error) => {
  console.error("🚨 Uncaught Exception:", error);
  process.exit(1);
});
